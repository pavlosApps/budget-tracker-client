import React from 'react'
export default function AddTransaction() {
  return <div className="p-4 text-xl">➕ Add Transaction (Coming soon)</div>
}
