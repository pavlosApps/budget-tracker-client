import React from 'react'
export default function Users() {
  return <div className="p-4 text-xl">👥 Users (Coming soon)</div>
}
