import React from 'react'
export default function Dashboard() {
  return <div className="p-4 text-xl">📊 Dashboard (Coming soon)</div>
}
